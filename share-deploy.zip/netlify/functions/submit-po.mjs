// 3DPX — Order by PO (invoice, no card). Creates a "Pre Sale" row in SLS Jobs flagged UNPAID,
// then attaches the uploaded STL(s) + optional PO document. No Stripe involved.
// Env: SMARTSHEET_TOKEN (required), SMARTSHEET_SHEET_ID (optional; defaults to SLS Jobs).
// Pricing is recomputed here (same model as create-checkout.mjs) for the quoted amount on record.

import { sendOrderEmail } from "./_notify.mjs";
import { logOrder } from "./_orderlog.mjs";
import { markQuoteOrdered } from "./_quotelog.mjs";
import { attachOrderFiles } from "./_attach.mjs";
import { shipCells } from "./_shipmap.mjs";

const SLS_JOBS_SHEET = "7474902212077444";
const COL = {
  orderStatus: 3699329920722820,
  poNumber:    2573430013880196,
  company:     1447530107037572,
  contact:     2432692525524868,
  price:       3704368460523396,
  volume:      2010480060458884,
  totalParts:  8202929548093316,
  color:       6514079687829380,
  dye:         4262279874144132,
  vapor:       5201233072940932,
  shipAddr:    347271731564420,
  poType:      8601217236946820,
  notes:       438442912337796,
  dueDate:     5951129734408068,
};

// ---- pricing (keep in sync with create-checkout.mjs) ----
const RULES = { volRate0:0.65, volRate100:0.55, bboxRate0:0.04, bboxRate100:0.03,
  bbVolThresh:3375, bbMult0:1.10, bbMult100:0.70, shellPrice:3, minPrice:0,
  orderMin:40, marketAdj:0.90,
  density:0.95,
  packBaseLb:0.6, packPerPartLb:0.05, packFactor:2.0, dimDivisor:139,
  shipRegionMult:{us:1.0, camx:1.6, intl:2.5},
  zoneStep:0.09, zoneMultMin:0.80, zoneMultMax:1.35,
  matCertFee:100, engRate:125 };
const ZIP_ZONE = {'0':5,'1':5,'2':5,'3':4,'4':3,'5':4,'6':2,'7':5,'8':6,'9':7};
function zoneMult(zip, region) {
  if (region && region !== "us") return 1;
  const d = (String(zip||"").match(/\d/)||[])[0];
  const zone = ZIP_ZONE[d] || 4;
  const m = Math.max(RULES.zoneMultMin, Math.min(RULES.zoneMultMax, 1 + (zone-4)*RULES.zoneStep));
  return Math.round(m*1000)/1000;
}
const FINISH = { dyePct:5, vsPct:30, vsMin:5, tumbFee:1.50, insertFee:1.50, tapFee:1.50, inspFee:1.50 };
const insCount = p => (p && p.inserts && +p.insertQty > 0) ? Math.floor(+p.insertQty) : 0;
const tapCnt  = p => (p && p.tapped && +p.tapQty > 0) ? Math.floor(+p.tapQty) : 0;
const inspCnt = p => (p && p.inspect && +p.inspQty > 0) ? Math.floor(+p.inspQty) : 0;
const PROMO = { "3DPXSAVE10":10, "3DPXSAVE5":5 };  // customer promo codes → % off list (keep in sync with the widget PROMO_CODES)
const SHIP_SPEEDS = {
  ground:    { label:"Ground shipping", base:12.5, perLb:1.15, min:12.5 },
  expedited: { label:"Expedited",       base:26,   perLb:2.60, min:26 },
  overnight: { label:"Overnight",       base:52,   perLb:5.25, min:52 },
  account:   { label:"Your carrier account", free:true },
  pickup:    { label:"Pickup at 3DPX",  free:true },
};
function shipWeightLb(parts) {
  let actualG=0, boxCC=0; const np=parts.length;
  for (const p of parts) { const q=Math.max(1,parseInt(p.qty)||1);
    actualG += (p.vol||0)*q*RULES.density;
    boxCC   += ((p.x*p.y*p.z)/1000)*q;
  }
  const actualLb=actualG/1000*2.20462;
  const packLb=RULES.packBaseLb+RULES.packPerPartLb*np;
  const dimLb=(boxCC*RULES.packFactor/16.387)/RULES.dimDivisor;
  return Math.max(actualLb+packLb, dimLb);
}
const QTY_BREAKS = [{q:1,d:0},{q:2,d:5},{q:10,d:12},{q:50,d:18},{q:100,d:25},{q:250,d:32},{q:500,d:38},{q:1000,d:45}];
const VALUE_BREAKS = [{v:200,d:5},{v:2000,d:10}];
const qd = q => { let d=0; for (const t of QTY_BREAKS) if (q>=t.q) d=t.d; return d; };
const vd = v => { let d=0; for (const t of VALUE_BREAKS) if (v>=t.v) d=t.d; return d; };
function unitPrice(p) {
  const bbox = (p.x*p.y*p.z)/1000;
  const density = bbox>0 ? Math.min(p.vol/bbox,1) : 0;
  const volRate  = RULES.volRate100  + (1-density)*(RULES.volRate0  - RULES.volRate100);
  const bboxRate = RULES.bboxRate100 + (1-density)*(RULES.bboxRate0 - RULES.bboxRate100);
  const bbMult = bbox>RULES.bbVolThresh ? RULES.bbMult100
    : RULES.bbMult100 + (RULES.bbVolThresh-bbox)/RULES.bbVolThresh*(RULES.bbMult0-RULES.bbMult100);
  let u = (volRate*p.vol + bboxRate*bbox)*bbMult + RULES.shellPrice*(p.shells||1);
  u = Math.max(u, RULES.minPrice);
  u *= RULES.marketAdj;
  const base = u;
  if (p.dye) u += base*FINISH.dyePct/100;
  if (p.vs)  u += (+p.vsp>0 ? +p.vsp : Math.max(base*FINISH.vsPct/100, FINISH.vsMin));  // rep hard-coded VS price wins
  if (p.tumble) u += FINISH.tumbFee;
  if (insCount(p)) u += FINISH.insertFee * insCount(p);
  if (tapCnt(p))  u += FINISH.tapFee * tapCnt(p);
  if (inspCnt(p)) u += FINISH.inspFee * inspCnt(p);
  return u;
}
function orderTotal(parts, region, matCert, speed, zip, addl, promoPct, eng) {
  // p.ov (rep per-unit override) → fixed line, excluded from all discounts.
  let discGross=0, postQty=0, fixedTot=0, hasNormal=false;
  for (const p of parts) {
    const q = Math.max(1, parseInt(p.qty)||1);
    const ov = (+p.ov>0) ? +p.ov : 0;
    if (p.manual && !(ov>0)) continue;   // unpriced manual-quote item: $0, same as the widget (never guess from geometry)
    if (ov>0) { fixedTot += ov*q; }
    else { const u = unitPrice(p); discGross += u*q; postQty += u*(1-qd(q)/100)*q; hasNormal=true; }
  }
  const vp = vd(discGross);
  let after = (postQty - postQty*vp/100);
  if (hasNormal) after = after * (1 - Math.max(0, Math.min(100, addl||0))/100);
  const pp = Math.max(0, Math.min(100, promoPct||0));  // promo: STACKS on top (% off the already-discounted subtotal)
  if (pp>0 && hasNormal) after = after * (1 - pp/100);
  after += fixedTot;
  const topUp = Math.max(0, RULES.orderMin - after);
  const shipping = shipEstimate(parts, region, speed, zip);
  const cert = matCert ? RULES.matCertFee : 0;
  return Math.round((after + topUp + shipping + cert + Math.max(0, +eng || 0))*100)/100;
}
// Estimated shipping charge (billable-weight model). 0 for pickup / free (carrier-account) methods.
function shipEstimate(parts, region, speed, zip) {
  const sp = SHIP_SPEEDS[speed] ? speed : "ground";
  if (sp==="pickup" || SHIP_SPEEDS[sp].free) return 0;
  const rm = RULES.shipRegionMult[region] || 1, s = SHIP_SPEEDS[sp];
  return Math.round(Math.max(s.min, s.base + s.perLb*shipWeightLb(parts))*rm*zoneMult(zip, region)*100)/100;
}
function leadDaysCalc(parts) {
  let tv = 0; for (const p of parts) tv += (p.vol||0)*Math.max(1, parseInt(p.qty)||1);
  let base = tv < 3000 ? 3 : Math.ceil(tv/4500 + 3);
  let fin = 0; for (const p of parts) { const ff = (p.dye?1:0)+(p.vs?1:0)+(p.tumble?1:0)+(insCount(p)?1:0)+(tapCnt(p)?1:0)+(inspCnt(p)?1:0); if (ff>fin) fin=ff; }
  return base + fin;
}

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  let body;
  try { body = await req.json(); } catch { return json({ error: "Bad request" }, 400); }

  const parts = Array.isArray(body.parts) ? body.parts : [];
  // Engineering-only orders carry no parts; validated after engHours is resolved below.
  const po = (body.po || "").toString().trim();
  const approved = !!body.approved;   // internal "approved in writing" order — no card, PO optional
  if (!po && !approved) return json({ error: "A PO number is required." }, 400);

  const token = process.env.SMARTSHEET_TOKEN;
  if (!token) return json({ error: "PO ordering isn't enabled yet." }, 503);
  const sheetId = process.env.SMARTSHEET_SHEET_ID || SLS_JOBS_SHEET;

  const speed = SHIP_SPEEDS[body.shipSpeed] ? body.shipSpeed : "ground";
  for (const p of parts) { if (p.ov != null) delete p.ov; if (p.vsp != null) delete p.vsp; }  // never trust client-supplied override / VS price
  let addlDisc = Math.max(0, +body.addlDisc || 0);
  let engHours = Math.max(0, +body.engHours || 0);
  let certWaive = false;  // rep-only; waives the material-cert fee (authoritative from the saved quote)
  let taxExemptQ = !!body.taxExempt;
  if (body.quoteId && /^Q-[A-Za-z0-9]{4,12}$/.test(body.quoteId)) {
    try { const { getStore } = await import("@netlify/blobs"); const q = await getStore("orders").get("Q-QUOTES/" + body.quoteId + ".json", { type: "json" }); if (q && typeof q.addlDisc === "number") addlDisc = Math.max(0, q.addlDisc); if (q && typeof q.engHours === "number") engHours = Math.max(0, q.engHours); if (q && typeof q.certWaive === "boolean") certWaive = q.certWaive; if (q && typeof q.taxExempt === "boolean") taxExemptQ = q.taxExempt; if (q && Array.isArray(q.parts)) q.parts.forEach((qp, i) => { if (parts[i] && qp && +qp.override > 0) parts[i].ov = +qp.override; if (parts[i] && qp && +qp.vsPrice > 0) parts[i].vsp = +qp.vsPrice; }); } catch (e) {}
  }
  if (!parts.length && !(engHours > 0)) return json({ error: "No parts or engineering services in order." }, 400);
  // A manual-quote item has no price, so ordering one online would under-bill the job and force a
  // follow-up invoice. Reps can clear it by setting a price override on the quote.
  if (body.source !== "internal" && parts.some(p => p.manual && !(+p.ov > 0))) {
    return json({ error: "Some items still need a manual quote and can't be ordered online yet. Please email sales@3dpx.com and we'll price them and send you a payment link." }, 409);
  }
  const promoPct = PROMO[String(body.promo||"").trim().toUpperCase()] || 0;
  const price = orderTotal(parts, body.region, (!!body.matCert && !certWaive), speed, body.zip, addlDisc, promoPct, engHours*RULES.engRate);
  const totalParts = parts.reduce((s,p)=>s+(Math.max(1,parseInt(p.qty)||1)),0);
  const totalVol   = Math.round(parts.reduce((s,p)=>s+(p.vol||0)*(Math.max(1,parseInt(p.qty)||1)),0)*100)/100;
  const dyeAny   = parts.some(p=>p.dye);
  const vaporAny = parts.some(p=>p.vs);

  const CLR = { natural:"White", black:"Black", blue:"Blue", green:"Green", red:"Red", yellow:"Yellow" };
  const colorVals = [...new Set(parts.map(p => (p.dye && CLR[p.color]) ? CLR[p.color] : "White"))];

  // Notes carries only what a person actually wrote — the order note and any per-part notes,
  // each labelled with its part. Payment type, PO, ship method and the part list are not
  // repeated here: they have their own columns, the Web Orders Log, or the attached traveler PDF.
  const partNotes = parts
    .map(p => { const n = String(p.notes || "").trim(); return n ? (String(p.name || "part").trim() + ": " + n) : ""; })
    .filter(Boolean);
  const acctInfo = (speed==="account") ? (" — " + (body.carrier||"carrier") + " acct " + (body.shipAccount||"(not provided)")) : "";
  const shipMethod = SHIP_SPEEDS[speed].label + (speed==="pickup" ? " (free)" : "") + acctInfo;
  // Keep the WEB- order number as the identifier (like card web orders), tagged with the customer PO.
  let webNo = (body.orderNo && /^WEB-(?:[0-9]{8}-)?[0-9]{3,6}$/.test(body.orderNo)) ? body.orderNo : null;
  if (!webNo) { try { const { getStore } = await import("@netlify/blobs"); const { allocateWebOrderNo } = await import("./_orderno.mjs"); webNo = await allocateWebOrderNo(getStore("orders")); } catch (e) { webNo = "WEB-" + Math.floor(1000+Math.random()*9000); } }
  const orderIdent = webNo + (po ? (" (PO " + po + ")") : (approved ? " (APPROVED)" : ""));

  // Idempotency guard: claim this order number exactly once, via a single conditional blob write.
  // (An earlier version read the ENTIRE SLS Jobs sheet here. That one call ate so much of the
  // function's time budget that attachOrderFiles below ran out of time mid-way and left the order's
  // PDFs sitting unattached in the blob store — so keep this O(1) and fast.)
  let claimStore = null;
  try {
    const { getStore } = await import("@netlify/blobs");
    claimStore = getStore("orders");
    const res = await claimStore.setJSON("ORDERED/" + webNo + ".json",
      { at: new Date().toISOString(), po, approved }, { onlyIfNew: true });
    if (res && res.modified === false) {
      console.log("submit-po idempotent skip — already claimed:", webNo);
      return json({ ok: true, order: po, duplicate: true });
    }
  } catch (e) {
    // A 412 here means another submission already claimed it → treat as a duplicate.
    if (claimStore) { console.log("submit-po idempotent skip (conflict):", webNo); return json({ ok: true, order: po, duplicate: true }); }
  }

  const custNote = String(body.note || "").trim();
  const notes = [custNote, ...partNotes].filter(Boolean).join(" | ").slice(0, 495);

  // Safety net: never record an order for printable parts when nothing was actually uploaded.
  // The widget blocks this per-part before it gets here; this catches a stale tab or a bypassed client.
  if (parts.length && !body.filesOverride) {
    try {
      const { getStore } = await import("@netlify/blobs");
      const listing = await getStore("orders").list({ prefix: webNo + "/" });
      const real = (listing.blobs || []).filter(b => { const r = b.key.slice((webNo + "/").length); return r && !r.startsWith(".part-") && !/\.(pdf|json)$/i.test(r); });
      // Files the widget reported as too big to upload are emailed in instead — they are a legitimate
      // reason for a part to have no blob, so count them alongside the uploads before refusing.
      const emailed = Array.isArray(body.oversizeFiles) ? body.oversizeFiles.length : 0;
      if (real.length + emailed < parts.length) return json({ error: "No part files were received for this order. Please re-add your files and try again, or email sales@3dpx.com." }, 409);
    } catch (e) { /* blob check unavailable — fall through rather than block a real order */ }
  }

  const contactVal = (body.name || "") + (body.email ? " <" + body.email + ">" : "");
  const due = /^\d{4}-\d{2}-\d{2}$/.test(String(body.dueDate||"")) ? body.dueDate : addBusinessDays(new Date(), leadDaysCalc(parts)).toISOString().slice(0,10);

  const cells = [
    { columnId: COL.orderStatus, value: "Pre Sale", strict: false },
    { columnId: COL.poNumber,    value: orderIdent },
    { columnId: COL.company,     value: body.company || body.name || "Web PO Order", strict: false },
    { columnId: COL.contact,     value: contactVal || "Web PO Order", strict: false },
    { columnId: COL.price,       value: price },
    { columnId: COL.volume,      value: totalVol },
    { columnId: COL.totalParts,  value: totalParts },
    { columnId: COL.dueDate,     value: due },
    { columnId: COL.color,       objectValue: { objectType: "MULTI_PICKLIST", values: colorVals }, strict: false },
    { columnId: COL.dye,         value: dyeAny },
    { columnId: COL.vapor,       value: vaporAny },
    { columnId: COL.shipAddr,    value: body.shipAddress || "" },
    { columnId: COL.poType,      value: "Standard", strict: false },
    { columnId: COL.notes,       value: notes },
  ];
  cells.push(...shipCells(speed));

  const r = await fetch("https://api.smartsheet.com/2.0/sheets/" + sheetId + "/rows", {
    method: "POST",
    headers: { Authorization: "Bearer " + token, "Content-Type": "application/json" },
    body: JSON.stringify([{ toBottom: true, cells }]),
  });
  const rowResp = await r.json().catch(() => ({}));
  if (!r.ok) {
    console.log("PO row create failed:", r.status, JSON.stringify(rowResp));
    return json({ error: "Couldn't record your PO. Please email your quote + PO to sales@3dpx.com." }, 502);
  }
  const rowId = rowResp.result && rowResp.result[0] && rowResp.result[0].id;

  // Notify the team + log to the capture-all orders sheet (best-effort).
  const payLabel = approved ? "Approved in writing — invoice on terms (no card)" : ("PO " + po + " — invoice on terms (unpaid)");
  await sendOrderEmail({
    kind: approved ? "Approved order" : "PO order", orderNo: orderIdent,
    company: body.company || body.name, contact: contactVal, price,
    pieces: totalParts, delivery: shipMethod, due, payment: payLabel, notes,
  });
  const logRow = await logOrder({
    orderNo: webNo, type: approved ? "Approved" : "PO", source: body.source === "internal" ? "Internal" : "Web",
    company: body.company || body.name, contact: body.name, email: body.email, phone: body.phone,
    amount: price, pieces: totalParts, volume: totalVol, colors: colorVals.join(", "),
    delivery: shipMethod, payment: payLabel, po, quoteId: body.quoteId, shipTo: body.shipAddress, notes,
    invoiceDue: new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10),  // Net 30 (PO + Approved)
    estShip: shipEstimate(parts, body.region, speed, body.zip),
  });

  // Attach uploaded STL(s) + PO doc to the SLS Jobs row AND the Web Orders Log row (best-effort).
  if (rowId && body.orderNo) {
    const targets = [{ sheetId, rowId }];
    if (logRow && logRow.rowId) targets.push(logRow);
    await attachOrderFiles(token, body.orderNo, targets);
  }

  if (body.quoteId) await markQuoteOrdered(body.quoteId);  // flip the source quote to "Ordered"

  return json({ ok: true, order: po });
};

function addBusinessDays(d, n) {
  const r = new Date(d); let added = 0;
  while (added < n) { r.setDate(r.getDate()+1); const day = r.getDay(); if (day!==0 && day!==6) added++; }
  return r;
}
function json(obj, status=200) {
  return new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json" } });
}
